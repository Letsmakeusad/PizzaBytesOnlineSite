﻿// Write your JavaScript code.
