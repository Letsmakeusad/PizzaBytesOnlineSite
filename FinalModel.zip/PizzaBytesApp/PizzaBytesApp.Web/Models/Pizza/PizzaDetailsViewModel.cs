﻿using PizzaBytesApp.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaBytesApp.Web.Models.Pizza
{
    public class PizzaDetailsViewModel
    {
        public PizzaDetailsServiceModel Pizza;
         
    }
}
