﻿using PizzaBytesApp.Data.Models;
using PizzaBytesApp.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaBytesApp.Web.Models.Order
{
    public class OrderDetailsViewModel
    {
        public OrderDetailsServiceModel Order;
    }
}
