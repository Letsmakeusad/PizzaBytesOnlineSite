﻿using PizzaBytesApp.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PizzaBytesApp.Services
{
    public interface IUserService
    {
         


    }
}
