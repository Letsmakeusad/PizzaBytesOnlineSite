﻿using System;

namespace PizzaBytesApp.Services
{
    public class IService
    {
    }
}
