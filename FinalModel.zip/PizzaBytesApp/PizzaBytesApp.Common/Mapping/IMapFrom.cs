﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaBytesApp.Common.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}
